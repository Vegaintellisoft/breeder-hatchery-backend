/**
 * Outbound push to SAP Breeder ICF services.
 * SAP expects JSON arrays or flat fields on the query string (typical for these z* services).
 */
const axios = require('axios');

const SAP_BASE = process.env.SAP_BASE_URL || 'http://krishidevqas.krishinutrition.com:8001/sap/bc/breeder';
const SAP_AUTH = {
  username: process.env.SAP_USER || 'vega',
  password: process.env.SAP_PASSWORD || 'Vega@1234',
};
const SAP_CLIENT = process.env.SAP_CLIENT || '500';

function toDmyFromDbDate(value) {
  if (!value) return '';
  const s = value instanceof Date ? value.toISOString().slice(0, 10) : String(value).slice(0, 10);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (!m) return '';
  return `${m[3]}/${m[2]}/${m[1]}`;
}

function numStr(v) {
  if (v === null || v === undefined || v === '') return '0';
  const n = Number(v);
  if (Number.isNaN(n)) return String(v);
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

function summarizeSapBody(data, httpStatus) {
  if (data == null || data === '') return `SAP HTTP ${httpStatus}`;
  if (typeof data === 'string') {
    const t = data.trim();
    if (t.length > 2000) return `${t.slice(0, 2000)}…`;
    return t || `SAP HTTP ${httpStatus}`;
  }
  try {
    return JSON.stringify(data);
  } catch {
    return `SAP HTTP ${httpStatus}`;
  }
}

async function postSap(endpoint, queryParams) {
  const url = `${SAP_BASE}/${endpoint}`;
  const res = await axios.post(url, null, {
    auth: SAP_AUTH,
    params: { 'sap-client': SAP_CLIENT, ...queryParams },
    timeout: 90000,
    maxRedirects: 5,
    validateStatus: () => true,
  });
  return res;
}

// ── Feed & Med (flock_feeding_log row) ────────────────────────────────────
function buildDmfdetRow(rec) {
  return {
    werks: String(rec.plant_code || '').trim(),
    aufnr: String(rec.order_no || '').trim(),
    plnbez: String(rec.flock_no || '').trim(),
    bldat: toDmyFromDbDate(rec.feed_date),
    matnr: String(rec.item_id || '').trim(),
    maktx: String(rec.item_name || '').trim(),
    meins: String(rec.uom || '').trim(),
    erfmgM: numStr(rec.qty_issued_male),
    erfmgF: numStr(rec.qty_issued_female),
  };
}

// ── Laying / egg collection header (+ aggregates) ────────────────────────
function buildBreegrnRows(header, flockRow, slotTotals, eggTypes) {
  const werks = String(header.plant_code || '').trim();
  const aufnr = String(header.order_no || '').trim();
  const matnr = String(header.flock_no || '').trim();
  const maktx = String(flockRow?.flock_name || '').trim();
  const batch = String(flockRow?.batch || '').trim();
  const hatchdt = toDmyFromDbDate(flockRow?.hatchery_date);
  const bldat = toDmyFromDbDate(header.collection_date);
  const zzflock = batch || '';
  const zzage = header.age_days != null ? numStr(header.age_days) : '';

  const fieldToEggType = new Map(
    (eggTypes || []).map((e) => [e.sap_field_key, e])
  );

  const rows = [];
  const keys = ['hatching_egg', 'table_egg', 'jumbo_egg', 'crack_egg', 'waste_reject_egg'];
  for (const key of keys) {
    const qty = parseFloat(slotTotals[key]) || 0;
    if (qty <= 0) continue;
    const et = fieldToEggType.get(key);
    const matnre = et?.egg_type_id || '';
    const maktxe = et?.egg_type_name || '';
    rows.push({
      werks,
      aufnr,
      matnr,
      maktx,
      batch,
      hatchdt,
      bldat,
      zzflock,
      zzage,
      zzstock: '',
      zzfstk: '',
      zzmstk: '',
      matnre,
      maktxe,
      meins: 'NOS',
      grqty: numStr(qty),
      estrate: numStr(qty),
    });
  }
  return rows;
}

// ── Mortality / Cull kill ─────────────────────────────────────────────────
function buildMorKillRow(rec) {
  return {
    werks: String(rec.plant_code || '').trim(),
    aufnr: String(rec.order_no || '').trim(),
    matnr: String(rec.flock_no || '').trim(),
    bldat: toDmyFromDbDate(rec.entry_date),
    fkimgF: numStr(rec.total_female),
    fkimgM: numStr(rec.total_male),
    fkimg: numStr(rec.total_qty),
  };
}

// ── Cull sale — flat query params ─────────────────────────────────────────
function buildCullSaleFlat(rec) {
  return {
    bldat: toDmyFromDbDate(rec.entry_date) || '',
    budat: '',
    zzcustype: String(rec.customer_type || ''),
    kunnr: '',
    bstnk: String(rec.dc_no || ''),
    bstdk: '',
    zzsaltype: String(rec.sales_type || ''),
    zztransby: String(rec.transport_by || ''),
    venum: String(rec.vehicle_no || ''),
    zzorderby: String(rec.order_by || ''),
    zzdispby: String(rec.dispatched_by || ''),
    werks: String(rec.plant_code || ''),
    aufnr: String(rec.order_no || ''),
    hatchdt: '',
    plnbez: String(rec.flock_no || ''),
    plnbezn: '',
    uom: '',
    batch: String(rec.batch_no || ''),
    zzage: rec.age != null ? String(rec.age) : '',
    zzstock: String(rec.bird_stock || ''),
    zzfstk: String(rec.net_weight_female || ''),
    zzmstk: String(rec.net_weight_male || ''),
    matnr: String(rec.flock_no || ''),
    maktx: '',
    meins: '',
    fkimgf: String(rec.net_weight_female || ''),
    fkimgm: String(rec.net_weight_male || ''),
    fkimg: String((parseFloat(rec.net_weight_male) || 0) + (parseFloat(rec.net_weight_female) || 0)),
    zzempwght: '',
    zzloadwght: '',
    weight: '',
    zzangwt: '',
    netpr: String(rec.rate || ''),
    netwr: String(rec.bill_value || ''),
  };
}

// ── Bird receipt / flock_bird_weight row ─────────────────────────────────
function buildBreAfruRow(rec) {
  return {
    werks: String(rec.plant_code || '').trim(),
    aufnr: String(rec.order_no || '').trim(),
    matnr: String(rec.flock_no || '').trim(),
    bldat: toDmyFromDbDate(rec.weight_date),
    zzfbwt: numStr(rec.male_weight),
    zzmbwt: numStr(rec.female_weight),
    menge: numStr((parseFloat(rec.male_weight) || 0) + (parseFloat(rec.female_weight) || 0)),
  };
}

/**
 * Load DB row(s) and post to SAP.
 * @returns {Promise<{ ok:boolean, status?:number, module:string, record_id:number|string, sap_response?:any, message?:string, error?:string }>}
 */
function interpretSapResponse(res) {
  const status = res.status;
  const sap_response = res.data;
  if (status >= 200 && status < 300) {
    return { ok: true, status, sap_response, message: null };
  }
  return {
    ok: false,
    status,
    sap_response,
    message: summarizeSapBody(sap_response, status),
  };
}

async function pushToSap(pool, module, recordId) {
  const id = parseInt(recordId, 10);
  if (!module || !recordId || Number.isNaN(id)) {
    return { ok: false, module, record_id: recordId, message: 'module and numeric record_id required' };
  }

  try {
    if (module === 'feeding') {
      const r = await pool.query(`SELECT * FROM flock_feeding_log WHERE id=$1`, [id]);
      if (r.rowCount === 0) return { ok: false, module, record_id: id, message: 'Record not found' };
      const row = r.rows[0];
      const payload = [buildDmfdetRow(row)];
      const res = await postSap('zfeed_med', { dmfdet: JSON.stringify(payload) });
      return { module, record_id: id, ...interpretSapResponse(res) };
    }

    if (module === 'egg_collection') {
      const h = await pool.query(`SELECT * FROM egg_collection_header WHERE id=$1`, [id]);
      if (h.rowCount === 0) return { ok: false, module, record_id: id, message: 'Record not found' };
      const header = h.rows[0];
      const fm = await pool.query(
        `SELECT flock_no, flock_name, batch, hatchery_date FROM flock_master WHERE flock_no=$1`,
        [header.flock_no]
      );
      const flockRow = fm.rows[0] || {};
      const slots = await pool.query(
        `SELECT table_egg, jumbo_egg, crack_egg, waste_reject_egg, hatching_egg
         FROM egg_collection_slots WHERE header_id=$1`,
        [id]
      );
      const totals = {
        table_egg: 0,
        jumbo_egg: 0,
        crack_egg: 0,
        waste_reject_egg: 0,
        hatching_egg: 0,
      };
      for (const s of slots.rows) {
        totals.table_egg += parseFloat(s.table_egg) || 0;
        totals.jumbo_egg += parseFloat(s.jumbo_egg) || 0;
        totals.crack_egg += parseFloat(s.crack_egg) || 0;
        totals.waste_reject_egg += parseFloat(s.waste_reject_egg) || 0;
        totals.hatching_egg += parseFloat(s.hatching_egg) || 0;
      }
      const eggTypes = (await pool.query(
        `SELECT egg_type_id, egg_type_name, sap_field_key FROM egg_type_lookup WHERE is_active=TRUE`
      )).rows;
      const breegrn = buildBreegrnRows(header, flockRow, totals, eggTypes);
      if (breegrn.length === 0) {
        return { ok: false, module, record_id: id, message: 'No egg quantities to send (all zero)' };
      }
      const res = await postSap('zlaying_prelay', { 'breegrn-': JSON.stringify(breegrn) });
      return { module, record_id: id, ...interpretSapResponse(res) };
    }

    if (module === 'mortality') {
      const r = await pool.query(`SELECT * FROM mortality_log WHERE id=$1`, [id]);
      if (r.rowCount === 0) return { ok: false, module, record_id: id, message: 'Record not found' };
      const payload = [buildMorKillRow(r.rows[0])];
      const res = await postSap('zmortality_ent', { 'bremor-': JSON.stringify(payload) });
      return { module, record_id: id, ...interpretSapResponse(res) };
    }

    if (module === 'cull_kill') {
      const r = await pool.query(`SELECT * FROM cull_kill_log WHERE id=$1`, [id]);
      if (r.rowCount === 0) return { ok: false, module, record_id: id, message: 'Record not found' };
      const payload = [buildMorKillRow(r.rows[0])];
      const res = await postSap('zculls_kill', { breckill: JSON.stringify(payload) });
      return { module, record_id: id, ...interpretSapResponse(res) };
    }

    if (module === 'cull_sales') {
      const r = await pool.query(`SELECT * FROM cull_sales_header WHERE id=$1`, [id]);
      if (r.rowCount === 0) return { ok: false, module, record_id: id, message: 'Record not found' };
      const flat = buildCullSaleFlat(r.rows[0]);
      const res = await postSap('zculls_sale', flat);
      return { module, record_id: id, ...interpretSapResponse(res) };
    }

    if (module === 'bird_receipt' || module === 'bird_weighing') {
      const r = await pool.query(`SELECT * FROM flock_bird_weight WHERE id=$1`, [id]);
      if (r.rowCount === 0) return { ok: false, module, record_id: id, message: 'Record not found' };
      const payload = [buildBreAfruRow(r.rows[0])];
      const res = await postSap('zbird_receipt', { breafru: JSON.stringify(payload) });
      return { module, record_id: id, ...interpretSapResponse(res) };
    }

    return { ok: false, module, record_id: id, message: `Unsupported module for SAP push: ${module}` };
  } catch (err) {
    const status = err.response?.status;
    const sap_response = err.response?.data;
    return {
      ok: false,
      module,
      record_id: id,
      message:
        sap_response != null
          ? summarizeSapBody(sap_response, status || 'error')
          : err.message,
      error: err.message,
      status,
      sap_response,
    };
  }
}

module.exports = {
  pushToSap,
  postSap,
  buildDmfdetRow,
  buildBreegrnRows,
  toDmyFromDbDate,
  summarizeSapBody,
  interpretSapResponse,
};
