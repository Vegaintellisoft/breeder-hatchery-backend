const axios = require('axios');

const SAP_BREEDER_BASE =
  process.env.SAP_BASE_URL || 'http://krishidevqas.krishinutrition.com:8001/sap/bc/breeder';
const SAP_MOBILE_BASE =
  process.env.SAP_MOBILE_BASE_URL || 'http://krishidevqas.krishinutrition.com:8001/sap/bc/mobile_app';
const SAP_AUTH = {
  username: process.env.SAP_USER || 'vega',
  password: process.env.SAP_PASSWORD || 'Vega@1234',
};
const SAP_CLIENT = process.env.SAP_CLIENT || '500';

const MODULE_ENDPOINTS = {
  feeding: 'zfeed_med',
  laying: 'zlaying_prelay',
  mortality: 'zmortality_ent',
  cull_kill: 'zculls_kill',
  cull_sale: 'zculls_sale',
  bird_receipt: 'zbird_receipt',
};

function normalizeModule(module) {
  if (!module) return null;
  const key = String(module).trim().toLowerCase();
  const aliases = {
    feed: 'feeding',
    feed_med: 'feeding',
    feeding: 'feeding',
    laying: 'laying',
    prelaying: 'laying',
    laying_prelay: 'laying',
    mortality: 'mortality',
    cull_kill: 'cull_kill',
    culls_kill: 'cull_kill',
    cull_sale: 'cull_sale',
    culls_sale: 'cull_sale',
    bird_receipt: 'bird_receipt',
    birdreceipt: 'bird_receipt',
  };
  return aliases[key] || null;
}

function getFlockFields(moduleKey) {
  if (moduleKey === 'feeding') {
    return { code: 'plnbez', name: 'plnbezN' };
  }
  if (moduleKey === 'cull_sale' || moduleKey === 'bird_receipt') {
    return { code: 'plnbez', name: 'plnbezN' };
  }
  return { code: 'matnr', name: 'maktx' };
}

async function fetchBreederData(moduleKey, werks, aufnr) {
  const endpoint = MODULE_ENDPOINTS[moduleKey];
  const params = { 'sap-client': SAP_CLIENT, werks };
  if (aufnr) params.aufnr = aufnr;

  const response = await axios.get(`${SAP_BREEDER_BASE}/${endpoint}`, {
    auth: SAP_AUTH,
    params,
    timeout: 30000,
  });

  const data = response.data;
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.results)) return data.results;
  return data ? [data] : [];
}

function buildOrderList(rows) {
  const map = new Map();
  for (const row of rows) {
    const orderNo = String(row.aufnr || '').trim();
    if (!orderNo) continue;
    if (map.has(orderNo)) continue;

    map.set(orderNo, {
      order_no: orderNo,
      plant_code: row.werks || null,
      hatch_date: row.hatchdt || null,
      batch: row.batch || null,
      label: orderNo,
    });
  }
  return Array.from(map.values());
}

function buildFlockList(rows, moduleKey) {
  const fields = getFlockFields(moduleKey);
  const map = new Map();

  const deriveStage = (ageDays) => {
    const age = Number(ageDays);
    if (!Number.isFinite(age)) return null;
    if (age <= 42) return 'Brooming';
    if (age <= 126) return 'Grooming';
    return 'Laying';
  };

  const toNum = (v) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : 0;
  };

  for (const row of rows) {
    const flockNo = String(row[fields.code] || '').trim();
    if (!flockNo) continue;

    const key = `${row.aufnr || ''}__${flockNo}`;
    const flockName = row[fields.name] ? String(row[fields.name]).replace(/\s+/g, ' ').trim() : flockNo;
    const ageDays = row.zzAge ?? null;
    const stockTotal = row.zzstock ?? row.stock ?? null;
    const femaleStock = row.zzFstk ?? null;
    const maleStock = row.zzMstk ?? null;

    if (!map.has(key)) {
      map.set(key, {
        order_no: row.aufnr || null,
        plant_code: row.werks || null,
        flock_no: flockNo,
        flock_name: flockName,
        hatch_date: row.hatchdt || null,
        age_days: ageDays,
        stage: deriveStage(ageDays),
        stock_total: stockTotal,
        total_count: stockTotal, // alias for UI
        female_stock: femaleStock,
        male_stock: maleStock,
        female_count: femaleStock, // alias for UI
        male_count: maleStock, // alias for UI
        count: stockTotal, // alias for UI
        mortality: 0,
        cull_kill: 0,
        cull_kill_count: 0,
        cull_sales: 0,
        bird_sales: 0,
        egg_collection: 0,
        batch: row.batch || null,
        label: `${flockNo} - ${flockName}`,
      });
    }

    const item = map.get(key);
    const qty = moduleKey === 'laying' ? toNum(row.grQty) : toNum(row.fkimg);
    if (moduleKey === 'mortality') item.mortality += qty;
    if (moduleKey === 'cull_kill') {
      item.cull_kill += qty;
      item.cull_kill_count += qty;
    }
    if (moduleKey === 'cull_sale') item.cull_sales += qty;
    if (moduleKey === 'bird_receipt') item.bird_sales += qty;
    if (moduleKey === 'laying') item.egg_collection += qty;
  }

  return Array.from(map.values());
}

exports.getPlants = async (req, res) => {
  try {
    const response = await axios.get(`${SAP_MOBILE_BASE}/shed_ready/get_plant`, {
      auth: SAP_AUTH,
      params: { 'sap-client': SAP_CLIENT },
      timeout: 30000,
    });

    const rows = Array.isArray(response.data) ? response.data : [];
    const plants = rows.map((row) => ({
      plant_code: String(row.Key || '').trim(),
      plant_name: String(row.Text || '').trim(),
      label: `${String(row.Key || '').trim()} - ${String(row.Text || '').trim()}`,
    }));

    return res.json({ success: true, total: plants.length, data: plants });
  } catch (err) {
    return res.status(503).json({
      success: false,
      message: 'Failed to fetch plants from SAP',
      error: err.message,
    });
  }
};

exports.getOrders = async (req, res) => {
  const moduleKey = normalizeModule(req.query.module);
  const { werks } = req.query;

  if (!moduleKey || !MODULE_ENDPOINTS[moduleKey]) {
    return res.status(422).json({
      success: false,
      message: 'module required',
      valid_modules: Object.keys(MODULE_ENDPOINTS),
    });
  }
  if (!werks) {
    return res.status(422).json({ success: false, message: 'werks required' });
  }

  try {
    const rows = await fetchBreederData(moduleKey, werks);
    const orders = buildOrderList(rows);
    return res.json({
      success: true,
      module: moduleKey,
      endpoint: MODULE_ENDPOINTS[moduleKey],
      werks,
      total: orders.length,
      data: orders,
    });
  } catch (err) {
    return res.status(503).json({
      success: false,
      message: 'Failed to fetch order numbers from SAP',
      error: err.message,
    });
  }
};

exports.getFlocks = async (req, res) => {
  const moduleKey = normalizeModule(req.query.module);
  const { werks, aufnr } = req.query;

  if (!moduleKey || !MODULE_ENDPOINTS[moduleKey]) {
    return res.status(422).json({
      success: false,
      message: 'module required',
      valid_modules: Object.keys(MODULE_ENDPOINTS),
    });
  }
  if (!werks || !aufnr) {
    return res.status(422).json({ success: false, message: 'werks and aufnr required' });
  }

  try {
    const rows = await fetchBreederData(moduleKey, werks, aufnr);
    const flocks = buildFlockList(rows, moduleKey);
    return res.json({
      success: true,
      module: moduleKey,
      endpoint: MODULE_ENDPOINTS[moduleKey],
      werks,
      aufnr,
      total: flocks.length,
      data: flocks,
    });
  } catch (err) {
    return res.status(503).json({
      success: false,
      message: 'Failed to fetch flocks from SAP',
      error: err.message,
    });
  }
};

exports.getChain = async (req, res) => {
  const moduleKey = normalizeModule(req.query.module);
  const { werks } = req.query;

  if (!moduleKey || !MODULE_ENDPOINTS[moduleKey]) {
    return res.status(422).json({
      success: false,
      message: 'module required',
      valid_modules: Object.keys(MODULE_ENDPOINTS),
    });
  }
  if (!werks) {
    return res.status(422).json({ success: false, message: 'werks required' });
  }

  try {
    const rows = await fetchBreederData(moduleKey, werks);
    const orders = buildOrderList(rows);
    const flocks = buildFlockList(rows, moduleKey);

    return res.json({
      success: true,
      module: moduleKey,
      endpoint: MODULE_ENDPOINTS[moduleKey],
      werks,
      orders_total: orders.length,
      flocks_total: flocks.length,
      orders,
      flocks,
    });
  } catch (err) {
    return res.status(503).json({
      success: false,
      message: 'Failed to fetch SAP dropdown chain',
      error: err.message,
    });
  }
};
